module.exports = {
    logger: true,
    logLevel: 'info',
    transporter: 'redis://redis-service',

    tracing: {
        enabled: true,
        exporter: ['Console'],
    },

    metrics: true,
    serializer: 'JSON',
};
