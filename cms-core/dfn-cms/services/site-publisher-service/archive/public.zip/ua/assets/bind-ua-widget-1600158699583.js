let timerId = setInterval(function(){
    if (document.getElementsByClassName("render-finished").length > 0){
        clearInterval(timerId);
        uaWidgetBinding();
    }
},100);

function uaWidgetBinding () {
    let uaContainerList = document.getElementsByClassName("ua-container-id");
    let uaWidgetList = document.getElementsByClassName("ua-widget-id");
    let uaPopupContainer = document.getElementById("ua-cms-popup-container");
    let appRoot = document.getElementById("ua-cms-root");

    appRoot.prepend(uaPopupContainer);

    if (uaContainerList.length > 0) {
        for (let i=0; i<uaWidgetList.length; i++) {
            let uaWidgetValue = uaWidgetList[i].attributes["ua-widget-id"].value;
            let uaWidgetDesc = uaWidgetValue.split('.')[uaWidgetValue.split('.').length-2]+uaWidgetValue.split('.')[uaWidgetValue.split('.').length-1];

            for (let j=0; j<uaContainerList.length; j++) {
                let uaContainerDesc = uaContainerList[j].attributes["ua-container-id"].value;

                if (uaWidgetDesc === uaContainerDesc) {
                    uaWidgetList[i].appendChild(uaContainerList[j]);
                }
            }
        }
    }
}