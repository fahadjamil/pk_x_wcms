var connectionParameters = {

  "tradeSettings": {

    "ip": "",
    "port": "",
    "secure": false
  },

  "priceSettings": {

    "ip": "m-bk-dev-price-universal.directfn.net/ws",
    "port": "",
    "secure": true
  }
}