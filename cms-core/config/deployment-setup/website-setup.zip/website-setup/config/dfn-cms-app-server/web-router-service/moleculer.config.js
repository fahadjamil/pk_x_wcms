module.exports = {
    logger: true,
    logLevel: 'info',
    transporter: {
        type: "Redis",
        options: {
            sentinels: [
                { host: "192.168.13.141", port: 26379 },
                { host: "192.168.14.165", port: 26379 },
				{ host: "192.168.14.166", port: 26379 },
            ],
            name: "mymaster",
        }
    },

    tracing: {
        enabled: true,
        exporter: ['Console'],
    },

    metrics: true,
    serializer: 'JSON',
};
