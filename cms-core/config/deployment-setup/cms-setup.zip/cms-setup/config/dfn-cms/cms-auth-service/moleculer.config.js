module.exports = {
    logger: true,
    logLevel: 'info',
    transporter: 'redis://redis-service',

    tracing: {
        enabled: true,
        exporter: ['Console'],
    },

    metrics: {
        enabled: true,
        reporter: [
            {
                type: "Prometheus",
                options: {
                    // HTTP port
                    port: 3030,
                    // HTTP URL path
                    path: "/metrics",
                    // Default labels which are appended to all metrics labels
                    defaultLabels: registry => ({
                        namespace: registry.broker.namespace,
                        nodeID: registry.broker.nodeID
                    })
                }
            }
        ]
    },
    serializer: 'JSON',
};
